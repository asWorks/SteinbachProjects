﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestFormulareAR
{
    public class Values
    {
        public string Value1 { get; set; }
        public string Value2 { get; set; }
        public string Value3 { get; set; }
        public string Disclaimer1 { get; set; }
        public string Adress { get; set; }
        public string Result { get; set; }
        public string Disclaimer2 { get; set; }

       public Values()
        {
            
        }
    }
}
