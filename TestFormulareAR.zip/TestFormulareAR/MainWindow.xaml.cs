﻿using GrapeCity.ActiveReports;
using GrapeCity.ActiveReports.Document;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;

namespace TestFormulareAR
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string CurrentFileLocation = System.AppDomain.CurrentDomain.BaseDirectory;
        public MainWindow()
        {
            InitializeComponent();

        }


      //Open Section Report
        private void Button_Click(object sender, RoutedEventArgs e)
        {

            var rpt = new SectionReport2();
            rpt.DataSource = GetDataSource(false);
            rpt.Run(true);
            ReportViewer.LoadDocument(rpt);

        }


        // Open Page Report
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
          
            ReportViewer.LocateDataSource += ReportViewer_LocateDataSource;
            ReportViewer.LoadDocument(CurrentFileLocation + @"\PageReport1.rdlx");
           

        }

     


        void ReportViewer_LocateDataSource(object sender, GrapeCity.ActiveReports.LocateDataSourceEventArgs args)
        {

            args.Data = GetDataSource(true);

        }




        private List<Values> GetDataSource(bool bAsync)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("John Smith");
            sb.AppendLine();
            sb.AppendLine("12345 Milky Way");
            sb.AppendLine("98745 Universe");

            int ln = 0;
            int vl = 0;
            int maxLines = 35;

            if (bAsync)
            {
                Task task = Task.Factory.StartNew(() =>
               {
                   this.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal, (new Action(() =>
                   {

                       ln = int.Parse(txtDisclaimerLines.Text);
                       vl = int.Parse(txtValueLines.Text);


                   })));

               });


                while (ln == 0 || vl == 0)
                {
                    Console.WriteLine("Waiting for Task");
                }

            }
            else
            {
                ln = int.Parse(txtDisclaimerLines.Text);
                vl = int.Parse(txtValueLines.Text);
            }





            List<string> disc2 = new List<string>(); 
            StringBuilder disclaimer = new StringBuilder();
            StringBuilder disclaimer2 = new StringBuilder();
            for (int i = 0; i < ln; i++)
            {
                if (i < maxLines )
                {
                     disclaimer.AppendLine(string.Format("Line number {0} of total lines {1}", i + 1, ln));
                }
                else
                {
                    disclaimer2.AppendLine(string.Format("Line number {0} of total lines {1}", i + 1, ln));
                }
               
               
            }



            List<Values> values = new List<Values>();
            for (int i = 0; i < vl; i++)
            {
                var x = new Values { Value1 = "Value 1 " + i, Value2 = "Value 2 " + i, Value3 = "Value 3 " + i };
                values.Add(x);
            }
            var query = from v in values
                        select
                        new Values
                        {
                            Value1 = v.Value1,
                            Value2 = v.Value2,
                            Value3 = v.Value3,
                            Disclaimer1 = disclaimer.ToString(),
                            Disclaimer2 = disclaimer2.ToString(),
                            Adress = sb.ToString(),
                            Result = "$ 1,325.00"
                           
                        };

            return query.ToList();



        }


    }
}
