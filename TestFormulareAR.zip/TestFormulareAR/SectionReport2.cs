using System;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;

namespace TestFormulareAR
{
    /// <summary>
    /// Summary description for SectionReport2.
    /// </summary>
    public partial class SectionReport2 : GrapeCity.ActiveReports.SectionReport
    {

        public SectionReport2()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();
        }

   
    }
}
